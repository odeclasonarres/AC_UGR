#include <stdio.h>
#include <stdlib.h>
#ifdef _OPENMP
#include <omp.h>
#else
#define omp_get_thread_num() 0
#endif

int main(int argc, char *argv[]){
	int filas, i,j, tmp;
	if(argc != 2){
		printf("Numero de parametros incorrecto\n");
		exit(-1);
	}
	filas = atoi(argv[1]);
	int matriz[filas][filas];
	int vector[filas], solucion[filas];
	for(i=0;i<filas;i++){
		vector[i] = i+1;
		solucion[i] = 0;
	}
	for(i=0;i<filas;i++){
		for(j=i;j<filas;j++){
			matriz[i][j] = 1;
		}
	}
	for(i=0;i<filas;i++){
		for(j=i;j<filas;j++){
			solucion[i] += matriz[i][j] * vector[j-i];
		}
	}

	printf("Componente 0: %d\nComponente N-1: %d\n", solucion[0], solucion[filas-1]);
	for(i=0;i<filas;i++){
		printf("%d ",solucion[i]);

	}
	printf("\n");
}
