#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#define MAX 32768
#define MIN 4096
int main(int argc, char *argv[]){

	if(argc != 2){
		printf("Numero de parametros incorrecto: tama\n");
		exit(-1);
	}
	int i, j, k, **matrizA, **matrizB, **matrizSol;
	int filas = atoi(argv[1]);
	//inicializacion de las 3 matrices;
	matrizA = (int**) malloc(filas*sizeof(int*));
	matrizB = (int**) malloc(filas*sizeof(int*));
	matrizSol = (int**) malloc(filas*sizeof(int*));
	for(i=0; i < filas; i++){
		matrizA[i] = (int*) malloc(filas*sizeof(int));
		matrizB[i] = (int*) malloc(filas*sizeof(int));
		matrizSol[i] = (int*) malloc(filas*sizeof(int));
	}
	for(i=0;i<filas;i++){
		for(j=0;j<filas;j++){
			matrizA[i][j] = 1;
			matrizB[i][j] = 1;
			matrizSol[i][j] = 0;
		}
	}
	//multiplicacion
	for (i=0;i<filas;i++){
		for (j=0;j<filas;j++){
			matrizSol[i][j] = 0;
		    for (k=1;k<filas;k++){
				matrizSol[i][j]=matrizSol[i][j]+matrizA[i][k]*matrizB[k][j];
			}
		}
	}
	printf("Componente 0: %d\nComponente N-1: %d\n", matrizSol[0][0], matrizSol[filas-1][filas-1]);
}
